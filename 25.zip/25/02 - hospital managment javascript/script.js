document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const dob = document.getElementById('dob').value;
    const address = document.getElementById('address').value;
    const gender = document.getElementById('gender').value;
    const medicalHistory = document.getElementById('medicalHistory').value;
    
    if (fullName === "" || email === "" || phone === "" || dob === "" || address === "" || gender === "" || medicalHistory === "") {
        alert("All fields are required!");
        return;
    }
    
    if (!validateEmail(email)) {
        alert("Please enter a valid email address.");
        return;
    }
    
    if (!validatePhone(phone)) {
        alert("Please enter a valid phone number.");
        return;
    }
    
    alert(`Registration successful!\nFull Name: ${fullName}\nEmail: ${email}\nPhone: ${phone}\nDate of Birth: ${dob}\nAddress: ${address}\nGender: ${gender}\nMedical History: ${medicalHistory}`);
    
    // Reset form
    document.getElementById('registrationForm').reset();
});

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}

function validatePhone(phone) {
    const re = /^[0-9]{10}$/;
    return re.test(String(phone));
}
