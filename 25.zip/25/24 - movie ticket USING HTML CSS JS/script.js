document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const movie = document.getElementById('movie').value;
    const tickets = document.getElementById('tickets').value;
    
    if (name === "" || email === "" || movie === "" || tickets === "") {
        alert("All fields are required!");
        return;
    }
    
    if (!validateEmail(email)) {
        alert("Please enter a valid email address.");
        return;
    }
    
    alert(`Tickets booked successfully!\nName: ${name}\nEmail: ${email}\nMovie: ${movie}\nTickets: ${tickets}`);
    
    // Reset form
    document.getElementById('bookingForm').reset();
});

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}
