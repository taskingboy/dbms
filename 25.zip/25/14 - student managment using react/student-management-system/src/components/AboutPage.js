// AboutPage.js
import React from 'react';

function AboutPage() {
  return (
    <div style={{ maxWidth: '600px', margin: 'auto' }}>
      <h1>About Us</h1>
      <p>
        This is the About page of our student management system. Lorem ipsum dolor sit amet, consectetur adipiscing
        elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
        exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
      </p>
    </div>
  );
}

export default AboutPage;